
package oop;
import java.awt.*; 
/**
 *
 * @author Admin
 */
public class Oop {

    public static void main(String[] args) {
        
    }
    
}
